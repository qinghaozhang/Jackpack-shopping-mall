
class Config{
    constructor(){

    }
}

Config.restUrl = 'REST API 基地址';
Config.onPay=true;  //是否启用支付

export {Config};